#FogCloud2Demo

>首先导入MiCOUser.jar和zxing.jar两个库

>添加资源文件：res/drawable-xhdpi下qr_code_bg.9.png，scan_line.png，shadow.png

>添加资源文件：res/layout下activity_capture.xml

>添加资源文件：res/raw下beep.ogg


