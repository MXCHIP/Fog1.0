package com.mxchip.activity;

import java.util.ArrayList;
import java.util.List;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.mico.micosdk.MiCODevice;
import com.mxchip.callbacks.EasyLinkCallBack;
import com.mxchip.callbacks.SearchDeviceCallBack;
import com.mxchip.constarg.FogHelp;

/**
 * 通过EasyLink配网，然后打开mDNS发现设备，并解析出设备的ip，通过http连接上，然后发送激活请求 项目名称：FogCloud2Demo
 * 创建人：Sin 创建时间：2016年1月18日 下午5:09:17
 * 
 * @version 1.0
 */
public class EasyLinkActivity extends Activity {

	private String TAG = "---EasyLinkActivity---";

	private EditText ssid;
	private EditText password;
	private EditText mdnsservername;
	private Button starteasylink;
	private Button stopeasylink;
	private Button startmdns;
	private Button stopmdns;
	private TextView mdnsinfo;

	// easylink 相关接口
	public MiCODevice micodev;
	private Context ctx = null;
	// mDNS相关接口

	private FogHelp fh;

	private JSONArray tempmDNS = null;
	List<String> list;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.easylink);

		initView();
		initOnClick();

		ctx = EasyLinkActivity.this;
		micodev = new MiCODevice(ctx);
		// mdnsApi = new MiCOmDNS();

		ssid.setText(micodev.getSSID());
		fh = new FogHelp();
	}

	private void initView() {
		ssid = (EditText) findViewById(R.id.ssid);
		password = (EditText) findViewById(R.id.password);
		mdnsservername = (EditText) findViewById(R.id.mdnsservername);
		starteasylink = (Button) findViewById(R.id.starteasylink);
		stopeasylink = (Button) findViewById(R.id.stopeasylink);
		startmdns = (Button) findViewById(R.id.startmdns);
		stopmdns = (Button) findViewById(R.id.stopmdns);
		mdnsinfo = (TextView) findViewById(R.id.mdnsinfo);
	}

	private void initOnClick() {
		// 开始EasyLink
		starteasylink.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Log.d(TAG, micodev.getSSID());

				String ssidStr = ssid.getText().toString().trim();
				String passwordStr = password.getText().toString();

				if (fh.checkPara(ssidStr, passwordStr)) {
					mdnsinfo.setText("开始EasyLink");
					/**
					 * !important 一般需要设置30-60s的定时器，超时后请主动关闭EasyLink
					 */
					micodev.startEasyLink(ssidStr, passwordStr, 60000,
							new EasyLinkCallBack() {

								@Override
								public void onSuccess(String message) {
									Log.d("---EasyLink---", message);
								}

								@Override
								public void onFailure(int code, String message) {
									Log.d("---EasyLink---", code + " "
											+ message);
								}
							});
				} else {
					fh.setToast(EasyLinkActivity.this, "参数为空");
				}
			}
		});
		stopeasylink.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				/**
				 * 关闭EasyLink
				 */
				mdnsinfo.setText("关闭EasyLink");
				micodev.stopEasyLink(new EasyLinkCallBack() {

					@Override
					public void onSuccess(String message) {
						Log.d("---EasyLink---", message);
					}

					@Override
					public void onFailure(int code, String message) {
						Log.d("---EasyLink---", code + " " + message);
					}
				});
			}
		});
		startmdns.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				mdnsinfo.setText("开始mDNS");
				new WorkThread().start();
			}
		});
		stopmdns.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				micodev.stopSearchDevices(new SearchDeviceCallBack() {

					@Override
					public void onSuccess(String message) {
						Log.d("---stopSearchDevices---", message);
						mdnsinfo.append("\r\n\n正在关闭mDNS, 保留最后一条记录");
						getBindDevByIP();
					}

					@Override
					public void onFailure(int code, String message) {
						Log.d("---stopSearchDevices---", code + " " + message);
						mdnsinfo.append("\r\n\n" + code + " " + message);
					}

					@Override
					public void onDevicesFind(JSONArray deviceStatus) {

					}
				});
			}
		});
	}

	private Handler handler = new Handler() {
		@Override
		public void handleMessage(Message msg) {

			if (msg.what == 1) {
				mdnsinfo.setText(msg.obj.toString());
			}
		}
	};

	private void getBindDevByIP() {
		if (null != tempmDNS) {
			JSONObject temp;
			list = new ArrayList<String>();
			for (int i = 0; i < tempmDNS.length(); i++) {
				try {
					temp = (JSONObject) tempmDNS.get(i);
					if (temp.getString("isHaveSuperUser").equals("false")) {
						list.add(temp.getString("deviceIP"));
					}
				} catch (JSONException e) {
					e.printStackTrace();
				}
			}
			Log.d(TAG, list.toString());

			new AlertDialog.Builder(EasyLinkActivity.this)
					.setTitle("是否激活以下设备")
					// 设置对话框标题
					.setMessage(list.toString())
					// 设置显示的内容
					.setPositiveButton("确定",
							new DialogInterface.OnClickListener() {// 添加确定按钮
								@Override
								public void onClick(DialogInterface dialog,
										int which) {// 确定按钮的响应事件
									
									Intent intent = new Intent(ctx, BindDeviceActivity.class);
									intent.putExtra("ips", list.toString());
									startActivity(intent);
									finish();
								}
							})
					.setNegativeButton("转本地控制",
							new DialogInterface.OnClickListener() {// 添加返回按钮
								@Override
								public void onClick(DialogInterface dialog,
										int which) {// 响应事件
									Intent intent = new Intent(ctx, CtrlLocalDevActivity.class);
									startActivity(intent);
								}
							}).show();// 在按键响应事件中显示此对话框
		}else{
			Toast.makeText(ctx, "貌似还没搜到设备吧", Toast.LENGTH_SHORT).show();
		}
	}

	// 工作线程
	private class WorkThread extends Thread {
		@Override
		public void run() {
			// 处理比较耗时的操作
			String serviceName = mdnsservername.getText().toString();
			micodev.startSearchDevices(serviceName, new SearchDeviceCallBack() {

				@Override
				public void onSuccess(String message) {
					Log.d("------onSuccess------", message);
				}

				@Override
				public void onFailure(int code, String message) {
					Log.d("------onFailure------", message);
				}

				@Override
				public void onDevicesFind(JSONArray deviceStatus) {
					if (!deviceStatus.equals("")) {
						Log.d("------OK------", deviceStatus.toString());
						// 处理完成后给handler发送消息
						Message msg = new Message();
						msg.obj = deviceStatus;
						msg.what = 1;
						handler.sendMessage(msg);
						tempmDNS = deviceStatus;
					}
				}
			});
		}
	}
}
