package com.mxchip.activity;

import android.app.Activity;
import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.mico.micosdk.MiCODevice;
import com.mxchip.callbacks.ManageDeviceCallBack;

public class BindDeviceActivity extends Activity {

	private String TAG = "---BindDeviceActivity---";

	private Button btBinding;
	private EditText etWillBindIP;
	private TextView mqttmessage;

	private MiCODevice micodev;
	private Context ctx;

	private SharedPreferences sharedPreferences;

	String ips;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.bingding);
		ips = (String) getIntent().getSerializableExtra("ips");

		initView();
		initOnClick();

		ctx = BindDeviceActivity.this;
		micodev = new MiCODevice(ctx);
		sharedPreferences = getSharedPreferences("fogcloud",
				Activity.MODE_PRIVATE);
	}

	private void initView() {
		btBinding = (Button) findViewById(R.id.btBinding);
		etWillBindIP = (EditText) findViewById(R.id.etWillBindIP);
		mqttmessage = (TextView) findViewById(R.id.mqttmessage);

		mqttmessage.setText("可以绑定的设备们："+ips);
	}

//	private boolean connectTag = false;
	private void initOnClick() {
		btBinding.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				String ip = etWillBindIP.getText().toString().trim();
				
				// 这里是测试绑定设备的接口
				micodev.bindDevice(ip, new ManageDeviceCallBack() {

							@Override
							public void onSuccess(String message) {
								Log.d(TAG, message);
								mqttmessage.setText(message);
							}

							@Override
							public void onFailure(int code, String message) {
								Log.d("---bindDevice---", code + " " + message);
								mqttmessage.setText(code + " " + message);
							}
						}, sharedPreferences.getString("token", ""));
				
				
				
				
//				String deviceid = ConstArgument.DEVICEID;
//				String devicepw = ConstArgument.DEVICEPW;
//				String vercode = "8ef613f4-df5b-11e5-a739-00163e0204c0";
//				
//				micodev.toBindingFogCloud(deviceid, devicepw, vercode, new ManageDeviceCallBack() {
//					
//					@Override
//					public void onSuccess(String message) {
//								Log.d(TAG, message);
//								mqttmessage.setText(message);
//					}
//					
//					@Override
//					public void onFailure(int code, String message) {
//								Log.d("---toBindingFogCloud---", code + " " + message);
//								mqttmessage.setText(code + " " + message);
//					}
//				}, sharedPreferences.getString("token", ""));
				
			}
		});
	}
}
