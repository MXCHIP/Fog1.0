package com.mxchip.constarg;

import android.content.Context;
import android.widget.Toast;

/**
 * 基础公共功能 项目名称：FogCloud2Demo 创建人：Sin 创建时间：2016年1月18日 下午4:32:28
 * 
 * @version 1.0
 */
public class FogHelp {

	/**
	 * 判断是否为空
	 * 
	 * @param param
	 * @return
	 */
	public boolean checkPara(String... param) {
		if (null == param || param.equals("")) {
			return false;
		} else if (param.length > 0) {
			for (String str : param) {
				if (null == str || str.equals("")) {
					return false;
				}
			}
			return true;
		}
		return false;
	}

	/**
	 * toast 一些信息
	 * @param context
	 * @param message
	 */
	public void setToast(Context context, String message) {
		if (checkPara(message) && (null != context)) {
			Toast.makeText(context, message, Toast.LENGTH_SHORT).show();
		}
	}

}
