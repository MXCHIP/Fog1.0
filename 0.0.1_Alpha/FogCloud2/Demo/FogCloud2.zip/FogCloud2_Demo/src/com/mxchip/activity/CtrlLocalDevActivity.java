package com.mxchip.activity;

import com.mico.micosdk.MiCODevice;
import com.mxchip.callbacks.SinSocketCallBack;
import com.mxchip.helper.SinSocketParams;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class CtrlLocalDevActivity extends Activity {
	
	private String TAG = "---CtrlLocalDevActivity---";
	
	private Button btnconnect;
	private Button btndisconnect;
	private Button sendlocalcommand;
	private EditText etlocaldevip;
	private EditText edlocalport;
	private EditText localcommand;
	private static TextView ctrlmessage;
	
	private MiCODevice micodev;
	private SinSocketCallBack sscb;
	
	private boolean connectTag = false;
	

	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.ctrllocaldev);
		
		initView();
		initOnClick();
		
		initListener();
		
		
		micodev = new MiCODevice(null);
	}
	
	private void initView() {
		btnconnect = (Button) findViewById(R.id.btnconnect);
		btndisconnect = (Button) findViewById(R.id.btndisconnect);
		sendlocalcommand = (Button) findViewById(R.id.sendlocalcommand);
		etlocaldevip = (EditText) findViewById(R.id.etlocaldevip);
		edlocalport = (EditText) findViewById(R.id.edlocalport);
		localcommand = (EditText) findViewById(R.id.localcommand);
		ctrlmessage = (TextView) findViewById(R.id.ctrlmessage);
		
		localcommand.setText("{\"heartbeat\":\"\"}");
	}
	
	private void initOnClick() {
		btnconnect.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				SinSocketParams sspara = new SinSocketParams();
				sspara.ip = etlocaldevip.getText().toString().trim();
				sspara.port = Integer.parseInt(edlocalport.getText().toString());
				sspara.heartBeatTime = 5000;
				sspara.overTime = 10000;
				sspara.autoConnectNo = 5;
				micodev.connectLocalDevice(sspara, sscb);
			}
		});
		btndisconnect.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				micodev.disconnectLocalDevice(new SinSocketCallBack() {
					@Override
					public void onSuccess(String message) {
						Log.d(TAG, "disconnect-->"+message);
						
						Message msg = new Message();
						msg.obj = "disconnect-->" + message;
						mHandler.sendMessage(msg);
					}
					
					@Override
					public void onFailure(int code, String message) {
						Log.d(TAG, "disconnect-->"+code + " " + message);
						
						Message msg = new Message();
						msg.obj = "disconnect-->"+code + " " + message;
						mHandler.sendMessage(msg);
					}
				});
			}
		});
		sendlocalcommand.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				String command = localcommand.getText().toString().trim();
				micodev.sendLocalCommand(command, new SinSocketCallBack() {
					@Override
					public void onSuccess(String message) {
						Log.d(TAG, "Command-->"+message);
						
						Message msg = new Message();
						msg.obj = "Command-->" + message;
						mHandler.sendMessage(msg);
					}
					
					@Override
					public void onFailure(int code, String message) {
						Log.d(TAG, "Command-->"+code + " " + message);
						
						Message msg = new Message();
						msg.obj = "Command-->"+code + " " + message;
						mHandler.sendMessage(msg);
					}
				});
			}
		});
	}
	
	private void initListener(){
		sscb = new SinSocketCallBack() {
			@Override
			public void onMessageRead(String message) {
				Log.d(TAG, "connect-->"+message);

				Message msg = new Message();
				msg.obj = "connect-->"+message;
				mHandler.sendMessage(msg);
			}
			@Override
			public void onLost() {
				Log.d(TAG, "connect-->"+"lost");
				
				Message msg = new Message();
				msg.obj = "connect-->"+"lost";
				mHandler.sendMessage(msg);
				
				connectTag = false;
			}
			
			@Override
			public void onSuccess(String message) {
				Log.d(TAG, "connect-->"+"success");

				Message msg = new Message();
				msg.obj = "connect-->"+"success";
				mHandler.sendMessage(msg);
				
				micodev.sendLocalCommand("{\"applocallogin\":\"admin\"}", null);
			}
			
			@Override
			public void onFailure(int code, String message) {
				Log.d(TAG, "connect-->"+code+" "+message);

				Message msg = new Message();
				msg.obj = "connect-->"+code+" "+message;
				mHandler.sendMessage(msg);
				
				connectTag = false;
			}
		};
	}
	
	private static Handler mHandler = new Handler(){ 
	    @Override
	    public void handleMessage(Message msg)
	    {
//	        if(msg.what == 1001)
//	        {
	            ctrlmessage.setText(msg.obj.toString());
//	        }
	    }
	};
}
