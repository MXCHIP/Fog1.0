package com.mxchip.activity;

import org.json.JSONException;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import com.mico.micosdk.MiCOUser;
import com.mxchip.callbacks.UserCallBack;
import com.mxchip.constarg.ConstArgument;
import com.mxchip.constarg.FogHelp;

/**
 * 用户登录界面 
 * 项目名称：FogCloud2Demo 
 * 创建人：Sin 
 * 创建时间：2016年1月18日 下午4:28:23
 * 
 * @version 1.0
 */
public class LoginActivity extends Activity {

	private EditText etUserName;
	private EditText edPassword;
	private Button btLogin;
	private TextView tvRegister;

	private String _APPID = ConstArgument._APPID;
	private MiCOUser micoUser = new MiCOUser();
	private SharedPreferences sharedPreferences;
	private SharedPreferences.Editor editor;
	private String TAG = "---LoginActivity---";

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login);

		sharedPreferences = getSharedPreferences("fogcloud",
				Activity.MODE_PRIVATE);
		editor = sharedPreferences.edit();

		initView();
		initOnClick();
	}

	private void initView() {
		etUserName = (EditText) findViewById(R.id.etUserName);
		edPassword = (EditText) findViewById(R.id.edPassword);
		btLogin = (Button) findViewById(R.id.btLogin);
		tvRegister = (TextView) findViewById(R.id.tvRegister);
	}

	private void initOnClick() {
		// 点击登录按钮
		btLogin.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				final FogHelp fh = new FogHelp();
				String userName = etUserName.getText().toString();
				String password = edPassword.getText().toString();

				if (fh.checkPara(userName, password)) {
					micoUser.login(userName, password, _APPID,
							new UserCallBack() {
								@Override
								public void onSuccess(String message) {
									Log.d(TAG, message.toString());
									try {
										// 将用户登录成功后获取的token放入local storege里
										editor.putString("token", new JSONObject(message).getString("token"));
										// 提交当前数据
										editor.commit();

										// 跳转到登录成功的首页
										Intent intent = new Intent(
												LoginActivity.this,
												HomePageActivity.class);
										startActivity(intent);

									} catch (JSONException e) {
										e.printStackTrace();
									}
								}

								@Override
								public void onFailure(int code, String message) {
									Log.d(TAG, message.toString());
									fh.setToast(LoginActivity.this, code + " " + message.toString());
								}
							});
				} else {
					fh.setToast(LoginActivity.this, "参数为空");
				}
			}
		});

		// 跳转到注册界面
		tvRegister.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(LoginActivity.this,
						CheckVerCodeActivity.class);
				startActivity(intent);
			}
		});
	}
}
