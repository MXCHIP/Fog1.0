package com.mxchip.activity;

import android.app.Activity;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import com.dtr.zxing.bean.ComminuteCode;
import com.mico.micosdk.MiCODevice;
import com.mxchip.callbacks.ManageDeviceCallBack;
import com.mxchip.constarg.ConstArgument;
import com.mxchip.helper.ShareDeviceParams;
import com.sin.qrcodeactivity.MiCOQrCodeActivity;

/**
 * 通过二维码分享设备给别人 项目名称：FogCloud2Demo 创建人：Sin 创建时间：2016年1月18日 下午5:08:55
 * 
 * @version 1.0
 */
public class QrCodeActivity extends Activity {

	private String TAG = "---QrCodeActivity---";

	private TextView codeinfo;
	private Button readcode;
	private Button unbinddev;
	private Button getsharecode;
	private ImageView qrcodeimg;

	private MiCODevice micoDev = new MiCODevice(QrCodeActivity.this);

	private SharedPreferences sharedPreferences;

	private String deviceid = ConstArgument.DEVICEID;
	private String devicepw = ConstArgument.DEVICEPW;
	private String bindingtype = ConstArgument.BINDINGTYPE;
	private int role = ConstArgument.ROLE;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.qrcode);
		sharedPreferences = getSharedPreferences("fogcloud", Activity.MODE_PRIVATE);
		initView();
		initOnclick();
	}

	private void initView() {
		codeinfo = (TextView) findViewById(R.id.codeinfo);
		qrcodeimg = (ImageView) findViewById(R.id.qrcodeimg);
		readcode = (Button) findViewById(R.id.readcode);
		unbinddev = (Button) findViewById(R.id.unbinddev);
		getsharecode = (Button) findViewById(R.id.getsharecode);
	}

	private void initOnclick() {
		// 打开摄像头读取二维码信息
		readcode.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				Intent intent = new Intent(QrCodeActivity.this,MiCOQrCodeActivity.class);
				// startActivity(intent);
				startActivityForResult(intent, ComminuteCode.RESULT_CODE);
			}
		});
		// 获取分享的vercode
		getsharecode.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {

				String jwttoken = sharedPreferences.getString("token", "");
				Log.d(TAG, jwttoken);

				micoDev.getShareVerCode(deviceid, new ManageDeviceCallBack() {

					@Override
					public void onSuccess(String message) {
						qrcodeimg.setImageBitmap(micoDev.creatQrCode(message, 220, 220));
					}

					@Override
					public void onFailure(int code, String message) {
						Log.d(TAG, message);
						codeinfo.setText(message);
					}
				}, jwttoken);
			}
		});
		// 解绑设备
		unbinddev.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				String jwttoken = sharedPreferences.getString("token", "");
				micoDev.unBindDevice(deviceid, new ManageDeviceCallBack() {
					
					@Override
					public void onSuccess(String message) {
						Log.d(TAG, message);
						codeinfo.setText(message);
					}
					
					@Override
					public void onFailure(int code, String message) {
						Log.d(TAG, message);
						codeinfo.setText(message);
					}
				}, jwttoken);
			}
		});
	}

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		if (requestCode == ComminuteCode.RESULT_CODE && !(null == data)) {
			// Log.d("---QrCodeActivity---",
			// "my code is -->" + data.getStringExtra("qrresult"));
			String vercode = data.getStringExtra("qrresult");
			codeinfo.setText(vercode);
			grantYourDevice(vercode);
		}
		super.onActivityResult(requestCode, resultCode, data);
	}

	/**
	 * 通过二维码读取到vercode，直接去绑定设备
	 * 
	 * @param vercode
	 */
	private void grantYourDevice(String vercode) {

		ShareDeviceParams sdevp = new ShareDeviceParams();

		sdevp.bindvercode = vercode;
		sdevp.deviceid = deviceid;
		sdevp.devicepw = devicepw;
		sdevp.role = role;
		sdevp.bindingtype = bindingtype;
		sdevp.iscallback = false;

		micoDev.addDeviceByVerCode(sdevp, new ManageDeviceCallBack() {
			
			@Override
			public void onSuccess(String message) {
				Log.d(TAG, message);
				codeinfo.setText(message);
			}
			
			@Override
			public void onFailure(int code, String message) {
				Log.d(TAG, message);
				codeinfo.setText(message);
			}
		}, sharedPreferences.getString("token", ""));

	}
}
