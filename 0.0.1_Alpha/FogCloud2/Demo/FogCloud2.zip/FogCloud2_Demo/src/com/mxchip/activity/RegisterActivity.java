package com.mxchip.activity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;

import com.mico.micosdk.MiCOUser;
import com.mxchip.callbacks.UserCallBack;
import com.mxchip.constarg.ConstArgument;
import com.mxchip.constarg.FogHelp;

/**
 * 设置密码完成注册 项目名称：FogCloud2Demo 创建人：Sin 创建时间：2016年1月18日 下午4:53:09
 * 
 * @version 1.0
 */
public class RegisterActivity extends Activity {

	private EditText rgPassword;
	private Button rgRegister;
	private Button fogetpassword;

	private MiCOUser micoUser = new MiCOUser();
	private String TAG = "---RegisterActivity---";

	private String token;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.register);

		token = (String) getIntent().getSerializableExtra("token");

		initView();
		initOnClick();
	}

	private void initView() {
		rgPassword = (EditText) findViewById(R.id.rgPassword);
		rgRegister = (Button) findViewById(R.id.rgRegister);
		fogetpassword = (Button) findViewById(R.id.fogetpassword);
	}

	private void initOnClick() {
		/**
		 * 设置密码注册用户
		 */
		rgRegister.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				final FogHelp fh = new FogHelp();
				String password = rgPassword.getText().toString();
				if (fh.checkPara(password)) {

					micoUser.register(password,password,new UserCallBack() {

						@Override
						public void onSuccess(String message) {
							Log.d(TAG, message);
							fh.setToast(RegisterActivity.this, "注册成功，请登录");

							/**
							 * 注册成功后跳到重新登录的界面
							 */
							Intent intent = new Intent(RegisterActivity.this,
									LoginActivity.class);
							startActivity(intent);
						}

						@Override
						public void onFailure(int code, String message) {
							Log.d(TAG, message);
							fh.setToast(RegisterActivity.this, message);
						}
					}, token);
				} else {
					fh.setToast(RegisterActivity.this, "参数为空");
				}
			}
		});

		// 忘记密码，一般在验证云端发来的 验证码后调用
		fogetpassword.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				final FogHelp fh = new FogHelp();
				String password = rgPassword.getText().toString();
				micoUser.resetPassword(password, new UserCallBack() {

					@Override
					public void onSuccess(String message) {
						Log.d(TAG, message);
						fh.setToast(RegisterActivity.this, "修改成功，请重新登录");

						/**
						 * 注册成功后跳到重新登录的界面
						 */
						Intent intent = new Intent(RegisterActivity.this, LoginActivity.class);
						startActivity(intent);
					}

					@Override
					public void onFailure(int code, String message) {
						Log.d(TAG, message);
						fh.setToast(RegisterActivity.this, message);
					}
				}, token);
			}
		});
	}
}
