//
//  UZModuleWifi.h
//  micoBind
//
//  Created by kenny on 15/5/5.
//  Copyright (c) 2015年 APICloud. All rights reserved.
//

#import "UZModule.h"

@interface UZModuleWifi : UZModule

@end
