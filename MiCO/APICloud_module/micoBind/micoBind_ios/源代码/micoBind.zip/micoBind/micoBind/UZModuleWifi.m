//
//  UZModuleWifi.m
//  micoBind
//
//  Created by kenny on 15/5/5.
//  Copyright (c) 2015年 APICloud. All rights reserved.
//

#import "UZModuleWifi.h"
#import "EASYLINK.h"
#import "NSDictionaryUtils.h"

@implementation UZModuleWifi

- (void)getSsid:(NSDictionary *)paramDict {
    NSInteger cbId = [paramDict integerValueForKey:@"cbId" defaultValue:-1];
    if (cbId < 0) {
        return;
    }
    NSString *ssid = [EASYLINK ssidForConnectedNetwork];
    if (ssid) {
        [self sendResultEventWithCallbackId:cbId dataDict:@{@"ssid":ssid} errDict:nil doDelete:YES];
    } else {
        [self sendResultEventWithCallbackId:cbId dataDict:nil errDict:@{@"msg":@"unknown error"} doDelete:YES];
    }
}

@end
