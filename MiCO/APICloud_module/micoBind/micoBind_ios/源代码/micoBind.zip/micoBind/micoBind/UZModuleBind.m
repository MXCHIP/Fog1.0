//
//  UZModuleBind.m
//  micoBind
//
//  Created by kenny on 15/5/5.
//  Copyright (c) 2015年 APICloud. All rights reserved.
//

#import "UZModuleBind.h"
#import "NSDictionaryUtils.h"
#import "EASYLINK.h"

@interface UZModuleBind ()
{
    EASYLINK *_easyLink;
    NSInteger _getIpCbId;
}

@property (nonatomic, strong) NSNumber *ftcClient;

@end

@implementation UZModuleBind

- (void)dispose {
    if (_easyLink) {
        [_easyLink setDelegate:nil];
    }
}

- (void)getDevip:(NSDictionary *)paramDict {
    _getIpCbId = [paramDict integerValueForKey:@"cbId" defaultValue:-1];
    NSString *wifi_ssid = [paramDict stringValueForKey:@"wifi_ssid" defaultValue:nil];
    NSString *wifi_password = [paramDict stringValueForKey:@"wifi_password" defaultValue:nil];
    if (!wifi_ssid || !wifi_password) {
        [self sendResultEventWithCallbackId:_getIpCbId dataDict:nil errDict:@{@"msg":@"param error"} doDelete:YES];
        _getIpCbId = -1;
        return;
    }
    
    NSString *ip = [EASYLINK getIPAddress];
    NSString *netMask = [EASYLINK getNetMask];
    NSString *geteWay = [EASYLINK getGatewayAddress];
    NSMutableDictionary *config = [NSMutableDictionary dictionary];
    [config setObject:[wifi_ssid dataUsingEncoding:NSUTF8StringEncoding] forKey:KEY_SSID];
    [config setObject:wifi_password forKey:KEY_PASSWORD];
    [config setObject:@(YES) forKey:KEY_DHCP];
    if (ip) {
        [config setObject:ip forKey:KEY_IP];
    }
    if (netMask) {
        [config setObject:netMask forKey:KEY_NETMASK];
    }
    if (geteWay) {
        [config setObject:geteWay forKey:KEY_GATEWAY];
        [config setObject:geteWay forKey:KEY_DNS1];
    }
    if (!_easyLink) {
        _easyLink = [[EASYLINK alloc] initWithDelegate:self];
    }
    [_easyLink prepareEasyLink_withFTC:config info:[@"" dataUsingEncoding:NSUTF8StringEncoding] mode:EASYLINK_V2_PLUS];
    [_easyLink transmitSettings];
}

- (void)stopFtc:(NSDictionary *)paramDict {
    NSInteger cbId = [paramDict integerValueForKey:@"cbId" defaultValue:-1];
    if (self.ftcClient) {
        [_easyLink closeFTCClient:self.ftcClient];
        self.ftcClient = nil;
    }
    [_easyLink stopTransmitting];
    [self sendResultEventWithCallbackId:cbId dataDict:@{@"status":@(YES)} errDict:nil doDelete:YES];
}

#pragma mark - EasyLinkFTCDelegate

- (void)onFoundByFTC:(NSNumber *)client withConfiguration: (NSDictionary *)configDict {
    self.ftcClient = client;
    NSLog(@"config: %@", configDict);
    if (_getIpCbId >= 0) {
        NSString *devip = nil;
        if ([configDict isKindOfClass:[NSDictionary class]]) {
            NSArray *array1 = [configDict arrayValueForKey:@"C" defaultValue:nil];
            if (array1.count > 1) {
                NSDictionary *dict = [array1 objectAtIndex:1];
                if ([dict isKindOfClass:[NSDictionary class]]) {
                    NSArray *array2 = [dict arrayValueForKey:@"C" defaultValue:nil];
                    if (array2.count > 3) {
                        NSDictionary *dictDevice = [array2 objectAtIndex:3];
                        if ([dictDevice isKindOfClass:[NSDictionary class]]) {
                            devip = [dictDevice stringValueForKey:@"C" defaultValue:nil];
                        }
                    }
                }
            }
        }
        if (devip.length > 0) {
            [_easyLink configFTCClient:client withConfiguration:@{}];
            [self sendResultEventWithCallbackId:_getIpCbId dataDict:@{@"devip":devip} errDict:nil doDelete:YES];
            _getIpCbId = -1;
        } else {
            [self sendResultEventWithCallbackId:_getIpCbId dataDict:nil errDict:@{@"msg":@"data parser error"} doDelete:NO];
        }
    }
}

@end
