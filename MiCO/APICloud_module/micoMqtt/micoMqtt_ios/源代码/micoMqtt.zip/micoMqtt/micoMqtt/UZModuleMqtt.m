//
//  UZModuleMqtt.m
//  micoMqtt
//
//  Created by kenny on 15/5/5.
//  Copyright (c) 2015年 APICloud. All rights reserved.
//

#import "UZModuleMqtt.h"
#import "UZModuleMqttManager.h"
#import "MosquittoClient.h"
#import "NSDictionaryUtils.h"

@interface UZModuleMqtt ()
<MosquittoClientDelegate>
{
    NSInteger _startCbId;
    NSInteger _publishCbId;
    NSInteger _stopCbId;
    NSInteger _listenerCbId;
}

@property (nonatomic, copy) NSString *subscribeTopic;

@end

@implementation UZModuleMqtt

- (id)initWithUZWebView:(UZWebView *)webView {
    if (self = [super initWithUZWebView:webView]) {
        _startCbId = -1;
        _publishCbId = -1;
        _stopCbId = -1;
        _listenerCbId = -1;
        [[UZModuleMqttManager manager] addHandler:self];
    }
    return self;
}

- (void)dispose {
    [[UZModuleMqttManager manager] removeHandler:self];
}

#pragma mark - Methods

- (void)startMqtt:(NSDictionary *)paramDict {
    _startCbId = [paramDict integerValueForKey:@"cbId" defaultValue:-1];
    NSString *host = [paramDict stringValueForKey:@"host" defaultValue:nil];
    NSString *clientID = [paramDict stringValueForKey:@"clientID" defaultValue:nil];
    NSString *topic = [paramDict stringValueForKey:@"topic" defaultValue:nil];
    if (!host || !clientID || !topic) {
        [self sendResultEventWithCallbackId:_startCbId dataDict:@{@"status":@(NO)} errDict:@{@"msg":@"param error"} doDelete:YES];
        _startCbId = -1;
        return;
    }
    self.subscribeTopic = topic;
    if ([[UZModuleMqttManager manager] isConnected]) {
        [[UZModuleMqttManager manager] subscribeTopic:topic];
    } else {
        NSString *username = [paramDict stringValueForKey:@"username" defaultValue:nil];
        NSString *password = [paramDict stringValueForKey:@"password" defaultValue:nil];
        [[UZModuleMqttManager manager] startWithHost:host username:username password:password clientID:clientID];
    }
}

- (void)publish:(NSDictionary *)paramDict {
    _publishCbId = [paramDict integerValueForKey:@"cbId" defaultValue:-1];
    NSString *topic = [paramDict stringValueForKey:@"topic" defaultValue:nil];
    NSString *command = [paramDict stringValueForKey:@"command" defaultValue:nil];
    if (!topic || !command) {
        [self sendResultEventWithCallbackId:_publishCbId dataDict:@{@"status":@(NO)} errDict:@{@"msg":@"param error"} doDelete:YES];
        _publishCbId = -1;
        return;
    }
    if (![[UZModuleMqttManager manager] isConnected]) {
        [self sendResultEventWithCallbackId:_publishCbId dataDict:@{@"status":@(NO)} errDict:@{@"msg":@"mqtt no started"} doDelete:YES];
        _publishCbId = -1;
        return;
    }
    [[UZModuleMqttManager manager] publishWithTopic:topic command:command];
}

- (void)stopMqtt:(NSDictionary *)paramDict {
    _stopCbId = [paramDict integerValueForKey:@"cbId" defaultValue:-1];
    if (![[UZModuleMqttManager manager] isConnected]) {
        [self sendResultEventWithCallbackId:_stopCbId dataDict:@{@"status":@(NO)} errDict:@{@"msg":@"mqtt no started"} doDelete:YES];
        _stopCbId = -1;
        return;
    }
    [[UZModuleMqttManager manager] stop];
    [self sendResultEventWithCallbackId:_stopCbId dataDict:@{@"status":@(YES)} errDict:nil doDelete:YES];
    _stopCbId = -1;
}

- (void)recvMqttMsg:(NSDictionary *)paramDict {
    _listenerCbId = [paramDict integerValueForKey:@"cbId" defaultValue:-1];
}

- (void)stopRecvMqttMsg:(NSDictionary *)paramDict {
    if (_listenerCbId >= 0) {
        [self deleteCallback:_listenerCbId];
        _listenerCbId = -1;
    }
}

#pragma mark - MosquittoClientDelegate

- (void)didConnect:(NSUInteger)code {
    if (self.subscribeTopic) {
        [[UZModuleMqttManager manager] subscribeTopic:self.subscribeTopic];
        self.subscribeTopic = nil;
    }
}

- (void)didDisconnect {
    if (_startCbId >= 0) {
        [self sendResultEventWithCallbackId:_startCbId dataDict:@{@"status":@(NO)} errDict:@{@"msg":@"disconnect"} doDelete:YES];
        _startCbId = -1;
    }
    if (_publishCbId >= 0) {
        [self sendResultEventWithCallbackId:_publishCbId dataDict:@{@"status":@(NO)} errDict:@{@"msg":@"disconnect"} doDelete:YES];
        _publishCbId = -1;
    }
    if (_stopCbId >= 0) {
        [self sendResultEventWithCallbackId:_stopCbId dataDict:@{@"status":@(YES)} errDict:nil doDelete:YES];
        _stopCbId = -1;
    }
}

- (void)didPublish:(NSUInteger)messageId {
    if (_publishCbId >= 0) {
        [self sendResultEventWithCallbackId:_publishCbId dataDict:@{@"status":@(YES)} errDict:nil doDelete:YES];
        _publishCbId = -1;
    }
}

- (void)didReceiveMessage:(MosquittoMessage *)mosq_msg {
    if (_listenerCbId >= 0) {
        if ([mosq_msg isKindOfClass:[MosquittoMessage class]]) {
            NSString *payload = mosq_msg.payload;
            if ([payload isKindOfClass:[NSString class]]) {
                NSData *data = [payload dataUsingEncoding:NSUTF8StringEncoding];
                id subs = [NSJSONSerialization JSONObjectWithData:data options:NSJSONReadingMutableContainers error:nil];
                if (subs) {
                    [self sendResultEventWithCallbackId:_listenerCbId dataDict:@{@"subs":subs} errDict:nil doDelete:NO];
                }
            }
        }
    }
}

- (void)didSubscribe:(NSUInteger)messageId grantedQos:(NSArray *)qos {
    if (_startCbId >= 0) {
        [self sendResultEventWithCallbackId:_startCbId dataDict:@{@"status":@(YES)} errDict:nil doDelete:YES];
        _startCbId = -1;
    }
}

- (void)didUnsubscribe:(NSUInteger)messageId {
    
}

@end
