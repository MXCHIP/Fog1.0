//
//  UZModuleMqttManager.h
//  micoMqtt
//
//  Created by kenny on 15/5/5.
//  Copyright (c) 2015年 APICloud. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "MosquittoClient.h"

@interface UZModuleMqttManager : NSObject

@property (nonatomic, readonly) BOOL isConnected;

+ (instancetype)manager;
- (void)addHandler:(id<MosquittoClientDelegate>)handler;
- (void)removeHandler:(id<MosquittoClientDelegate>)handler;
- (void)startWithHost:(NSString *)host
             username:(NSString *)username
             password:(NSString *)password
             clientID:(NSString *)clientID;
- (void)subscribeTopic:(NSString *)topic;
- (void)publishWithTopic:(NSString *)topic
                 command:(NSString *)command;
- (void)stop;

@end
