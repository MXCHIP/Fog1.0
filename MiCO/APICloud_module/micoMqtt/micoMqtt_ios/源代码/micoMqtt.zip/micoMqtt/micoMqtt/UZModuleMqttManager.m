//
//  UZModuleMqttManager.m
//  micoMqtt
//
//  Created by kenny on 15/5/5.
//  Copyright (c) 2015年 APICloud. All rights reserved.
//

#import "UZModuleMqttManager.h"

@interface UZModuleMqttManager ()
<MosquittoClientDelegate>

@property (nonatomic) MosquittoClient *mqttClient;
@property (nonatomic, strong) NSMutableArray *handlers;
@property (nonatomic) BOOL isConnected;
@property (nonatomic) BOOL userHaveStoppedMqtt;

@end

@implementation UZModuleMqttManager

static UZModuleMqttManager *g_manager = nil;

- (id)init {
    if (self = [super init]) {
        self.handlers = [NSMutableArray array];
    }
    return self;
}

+ (instancetype)manager {
    if (!g_manager) {
        g_manager = [[UZModuleMqttManager alloc] init];
    }
    return g_manager;
}

- (void)addHandler:(id<MosquittoClientDelegate>)handler {
    if (![self.handlers containsObject:handler]) {
        [self.handlers addObject:handler];
    }
}

- (void)removeHandler:(id<MosquittoClientDelegate>)handler {
    if ([self.handlers containsObject:handler]) {
        [self.handlers removeObject:handler];
    }
}

- (void)startWithHost:(NSString *)host
             username:(NSString *)username
             password:(NSString *)password
             clientID:(NSString *)clientID {
    if (!self.isConnected) {
        MosquittoClient *client = [[MosquittoClient alloc] initWithClientId:clientID];
        client.delegate = self;
        client.host = host;
        client.username = username;
        client.password = password;
        [client connect];
        self.mqttClient = client;
    }
}

- (void)subscribeTopic:(NSString *)topic {
    if (self.isConnected) {
        [self.mqttClient subscribe:topic];
    }
}

- (void)publishWithTopic:(NSString *)topic
                 command:(NSString *)command {
    if (self.isConnected) {
        [self.mqttClient publishString:command toTopic:topic withQos:0 retain:NO];
    }
}

- (void)stop {
    self.userHaveStoppedMqtt = YES;
    if (self.isConnected) {
        [self.mqttClient disconnect];
    }
    self.isConnected = NO;
}

#pragma mark - MosquittoClientDelegate

- (void)didConnect:(NSUInteger)code {
    self.userHaveStoppedMqtt = NO;
    self.isConnected = YES;
    for (id <MosquittoClientDelegate> handler in self.handlers) {
        if ([handler respondsToSelector:@selector(didConnect:)]) {
            [handler didConnect:code];
        }
    }
}

- (void)didDisconnect {
    self.isConnected = NO;
    if (!self.userHaveStoppedMqtt) {
        [self.mqttClient connect];
    }
    for (id <MosquittoClientDelegate> handler in self.handlers) {
        if ([handler respondsToSelector:@selector(didDisconnect)]) {
            [handler didDisconnect];
        }
    }
}

- (void)didPublish:(NSUInteger)messageId {
    for (id <MosquittoClientDelegate> handler in self.handlers) {
        if ([handler respondsToSelector:@selector(didPublish:)]) {
            [handler didPublish:messageId];
        }
    }
}

- (void)didReceiveMessage:(MosquittoMessage *)mosq_msg {
    for (id <MosquittoClientDelegate> handler in self.handlers) {
        if ([handler respondsToSelector:@selector(didReceiveMessage:)]) {
            [handler didReceiveMessage:mosq_msg];
        }
    }
}

- (void)didSubscribe:(NSUInteger)messageId grantedQos:(NSArray *)qos {
    for (id <MosquittoClientDelegate> handler in self.handlers) {
        if ([handler respondsToSelector:@selector(didSubscribe:grantedQos:)]) {
            [handler didSubscribe:messageId grantedQos:qos];
        }
    }
}

- (void)didUnsubscribe:(NSUInteger)messageId {
    for (id <MosquittoClientDelegate> handler in self.handlers) {
        if ([handler respondsToSelector:@selector(didUnsubscribe:)]) {
            [handler didUnsubscribe:messageId];
        }
    }
}

@end
